import edu.princeton.cs.algs4.Queue;

import java.util.Arrays;

public class FastCollinearPoints {
    private static final int MIN_LENGTH_SEGMENTS = 4;
    private int numberOfSegments = 0;

    private final LineSegment[] lineSegments;

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        if (points == null)
            throw new IllegalArgumentException("argument to FastCollinearPoints constructor is null");

        Queue<Point> allPointsQueue = new Queue<Point>();

        for (int i = 0; i < points.length; i++) {
            Point p = points[i];
            if (p == null)
                throw new IllegalArgumentException("point in the array is null");

            for (int j = 0; j < allPointsQueue.size(); j++) {
                Point q = allPointsQueue.dequeue();
                if (p.compareTo(q) == 0) {
                    throw new IllegalArgumentException("the argument to the constructor contains a repeated point");
                } else {
                    allPointsQueue.enqueue(q);
                }
            }
            allPointsQueue.enqueue(p);
        }

        double[] slopes = new double[points.length];
        double[] sortedSlopes = new double[points.length];
        Queue<Point> segmentsQueue = new Queue<Point>();

        for (int x = 0; x < points.length; x++) {
            Point p = points[x];

            for (int i = 0; i < points.length; i++) {
                slopes[i] = p.slopeTo(points[i]);
            }

            System.arraycopy(slopes, 0, sortedSlopes, 0, points.length);
            Arrays.sort(sortedSlopes);

            Point[] pointsSorted = new Point[points.length];
            System.arraycopy(points, 0, pointsSorted, 0, points.length);
            Arrays.sort(pointsSorted, p.slopeOrder());

            Point lo = null;
            Point hi = null;
            int number;
            for (int j = 0; j < sortedSlopes.length; j++) {
                number = 0;
                for (int k = j + 1; k < sortedSlopes.length; k++) {
                    if (k != j && sortedSlopes[k] == sortedSlopes[j]) {
                        if (sortedSlopes[k] == Double.NEGATIVE_INFINITY)
                            break;

                        number++;

                        if (number == MIN_LENGTH_SEGMENTS - 2) {
                            // p with first
                            lo = findMin(p, pointsSorted[j]);
                            hi = findMax(p, pointsSorted[j]);

                            // lo with second
                            lo = findMin(lo, pointsSorted[k - 1]);
                            hi = findMax(hi, pointsSorted[k - 1]);

                            // lo with third
                            lo = findMin(lo, pointsSorted[k]);
                            hi = findMax(hi, pointsSorted[k]);
                        } else if (number > 2) {
                            lo = findMin(lo, pointsSorted[k]);
                            hi = findMax(hi, pointsSorted[k]);
                        }

                        // last element
                        if (k == sortedSlopes.length - 1) {
                            if (number >= 2) {
                                segmentsQueue.enqueue(lo);
                                segmentsQueue.enqueue(hi);
                                j = j + number;
                            }
                        }
                    }
                    // when next non equal slope found
                    else {
                        if (number >= 2) {
                            segmentsQueue.enqueue(lo);
                            segmentsQueue.enqueue(hi);
                            j = j + number;
                            number = 0;
                        }
                        break;
                    }
                }
            }
        }

        Queue<Point> finalSegmentsQueue = new Queue<Point>();

        while (!segmentsQueue.isEmpty()) {
            Point q1 = segmentsQueue.dequeue();
            Point q2 = segmentsQueue.dequeue();
            finalSegmentsQueue.enqueue(q1);
            finalSegmentsQueue.enqueue(q2);

            for (int j = 0; j < segmentsQueue.size() + 2; j++) {
                if (!segmentsQueue.isEmpty()) {
                    Point w1 = segmentsQueue.dequeue();
                    Point w2 = segmentsQueue.dequeue();
                    if (!q1.equals(w1) || !q2.equals(w2)) {
                        segmentsQueue.enqueue(w1);
                        segmentsQueue.enqueue(w2);
                    }
                }
            }
        }

        lineSegments = new LineSegment[finalSegmentsQueue.size() / 2];
        numberOfSegments = finalSegmentsQueue.size() / 2;

        int i = 0;
        while (!finalSegmentsQueue.isEmpty()) {

            Point q1 = finalSegmentsQueue.dequeue();
            Point q2 = finalSegmentsQueue.dequeue();

            LineSegment ls = new LineSegment(q1, q2);
            lineSegments[i] = ls;
            i++;
        }
    }

    private Point findMin(Point a, Point b) {
        if (a.compareTo(b) <= 0)
            return a;
        return b;
    }

    private Point findMax(Point a, Point b) {
        if (a.compareTo(b) >= 0)
            return a;
        return b;
    }

    // the number of line segments
    public int numberOfSegments() {
        return numberOfSegments;
    }

    // the line segments
    public LineSegment[] segments() {
        LineSegment[] auxLineSegments = new LineSegment[lineSegments.length];
        System.arraycopy(lineSegments, 0, auxLineSegments, 0, lineSegments.length);
        return auxLineSegments;
    }
}