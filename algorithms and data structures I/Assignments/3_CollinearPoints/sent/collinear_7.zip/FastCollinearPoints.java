import edu.princeton.cs.algs4.Queue;

import java.util.Arrays;

public class FastCollinearPoints {
    private static final int MIN_LENGTH_SEGMENTS = 4;
    private int numberOfSegments = 0;

    private LineSegment[] lineSegments;

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        if (points == null)
            throw new IllegalArgumentException("argument to FastCollinearPoints constructor is null");

        Queue<Point> allPointsQueue = new Queue<Point>();
        for (int x = 0; x < points.length; x++) {
            Point p = points[x];
            if (p == null)
                throw new IllegalArgumentException("point in the array is null");

            for (int j = 0; j < allPointsQueue.size(); j++) {
                Point q = allPointsQueue.dequeue();
                if (p.compareTo(q) == 0) {
                    throw new IllegalArgumentException("the argument to the constructor contains a repeated point");
                } else {
                    allPointsQueue.enqueue(q);
                }
            }
            allPointsQueue.enqueue(p);
        }

        double[] slopes = new double[points.length];
        double[] sortedSlopes = new double[points.length];
        Queue<Point> segmentsQueue = new Queue<Point>();

        for (int x = 0; x < points.length; x++) {
            Point p = points[x];

            for (int i = 0; i < points.length; i++) {
                slopes[i] = p.slopeTo(points[i]);
            }

            System.arraycopy(slopes, 0, sortedSlopes, 0, points.length);
            Arrays.sort(sortedSlopes);

            Point[] pointsSorted = new Point[points.length];
            System.arraycopy(points, 0, pointsSorted, 0, points.length);
            Arrays.sort(pointsSorted, p.slopeOrder());

            Point lo = null;
            Point hi = null;
            int number = 2;
            for (int j = 0; j < sortedSlopes.length; j++) {
                if (j == 0)
                    continue;
                if (sortedSlopes[j] == sortedSlopes[j - 1]) {
                    number++;

                    if (number == MIN_LENGTH_SEGMENTS) {
                        // p with first
                        lo = findMin(p, pointsSorted[j - 2]);
                        hi = findMax(p, pointsSorted[j - 2]);

                        // lo with second
                        lo = findMin(lo, pointsSorted[j - 1]);
                        hi = findMax(hi, pointsSorted[j - 1]);

                        // lo with third
                        lo = findMin(lo, pointsSorted[j]);
                        hi = findMax(hi, pointsSorted[j]);
                    } else if (number > MIN_LENGTH_SEGMENTS) {
                        lo = findMin(lo, pointsSorted[j]);
                        hi = findMax(hi, pointsSorted[j]);
                    }

                    // last element
                    if (j == sortedSlopes.length - 1) {
                        if (number >= MIN_LENGTH_SEGMENTS) {
                            segmentsQueue.enqueue(lo);
                            segmentsQueue.enqueue(hi);
                        }
                    }
                }
                // when next non equal slope found
                else {
                    if (number >= MIN_LENGTH_SEGMENTS) {
                        segmentsQueue.enqueue(lo);
                        segmentsQueue.enqueue(hi);
                    }
                    number = 2;
                }
            }
        }

        LineSegment[] auxLineSegments = new LineSegment[segmentsQueue.size() / 2];

        while (!segmentsQueue.isEmpty()) {
            Point q1 = segmentsQueue.dequeue();
            Point q2 = segmentsQueue.dequeue();
            LineSegment ls = new LineSegment(q1, q2);
            auxLineSegments[numberOfSegments] = ls;
            numberOfSegments++;

            for (int j = 0; j < segmentsQueue.size(); j++) {
                if (!segmentsQueue.isEmpty()) {
                    Point w1 = segmentsQueue.dequeue();
                    Point w2 = segmentsQueue.dequeue();
                    j = j - 1;
                    if (!q1.equals(w1) || !q2.equals(w2)) {
                        segmentsQueue.enqueue(w1);
                        segmentsQueue.enqueue(w2);
                        j = j + 1;
                    }
                } else break;
            }
        }

        lineSegments = new LineSegment[numberOfSegments];
        System.arraycopy(auxLineSegments, 0, lineSegments, 0, numberOfSegments);
    }

    private Point findMin(Point a, Point b) {
        if (a.compareTo(b) <= 0)
            return a;
        return b;
    }

    private Point findMax(Point a, Point b) {
        if (a.compareTo(b) >= 0)
            return a;
        return b;
    }

    // the number of line segments
    public int numberOfSegments() {
        return numberOfSegments;
    }

    // the line segments
    public LineSegment[] segments() {
        LineSegment[] auxLineSegments = new LineSegment[lineSegments.length];
        System.arraycopy(lineSegments, 0, auxLineSegments, 0, lineSegments.length);
        return auxLineSegments;
    }
}