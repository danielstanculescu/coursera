import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdRandom;

public class Board {

    private Board twinBoard;

    private final int n;
    private final int[][] tiles;

    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] tiles) {
        this.n = tiles.length;
        this.tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            System.arraycopy(tiles[i], 0, this.tiles[i], 0, n);
    }

    // string representation of this board
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(n + "\n");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                s.append(String.format("%2d ", tiles[i][j]));
            }
            s.append("\n");
        }
        return s.toString();
    }

    // board dimension n
    public int dimension() {
        return n;
    }

    // number of tiles out of place
    public int hamming() {
        int result = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (tiles[i][j] != 0)
                    result += isTileGoal(tiles[i][j], i, j);
            }
        }
        return n * n - 1 - result;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan() {
        int result = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (tiles[i][j] != 0)
                    result += distanceToGoal(tiles[i][j], i, j);
            }
        }
        return result;
    }

    // is this board the goal board?
    public boolean isGoal() {
        return hamming() == 0;
    }

    // does this board equal y?
    public boolean equals(Object y) {

        if (y == this) {
            return true;
        }
        if (!(y.getClass() == Board.class)) {
            return false;
        }

        Board b = (Board) y;
        if (n != b.n)
            return false;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (tiles[i][j] != b.tiles[i][j])
                    return false;
            }
        }
        return true;
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {
        Queue<Board> neighbors = new Queue<Board>();

        int i = 0, j = 0;

        // find x position and y position of the tile 0
        outer:
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                if (tiles[i][j] == 0)
                    break outer;
            }
        }

        // tile 0 with right
        if (i < n - 1) {
            int[][] tilesClone = new int[n][n];
            for (int k = 0; k < n; k++) {
                System.arraycopy(tiles[k], 0, tilesClone[k], 0, n);
            }

            exch(tilesClone, i, j, i + 1, j);
            Board neighbour = new Board(tilesClone);
            neighbors.enqueue(neighbour);
        }

        // tile 0 with left
        if (i > 0) {
            int[][] tilesClone = new int[n][n];
            for (int k = 0; k < n; k++) {
                System.arraycopy(tiles[k], 0, tilesClone[k], 0, n);
            }
            exch(tilesClone, i, j, i - 1, j);
            Board neighbour = new Board(tilesClone);
            neighbors.enqueue(neighbour);
        }

        // tile 0 with up
        if (j > 0) {
            int[][] tilesClone = new int[n][n];
            for (int k = 0; k < n; k++) {
                System.arraycopy(tiles[k], 0, tilesClone[k], 0, n);
            }
            exch(tilesClone, i, j, i, j - 1);
            Board neighbour = new Board(tilesClone);
            neighbors.enqueue(neighbour);
        }

        // tile 0 with down
        if (j < n - 1) {
            int[][] tilesClone = new int[n][n];
            for (int k = 0; k < n; k++) {
                System.arraycopy(tiles[k], 0, tilesClone[k], 0, n);
            }
            exch(tilesClone, i, j, i, j + 1);
            Board neighbour = new Board(tilesClone);
            neighbors.enqueue(neighbour);
        }
        return neighbors;
    }

    // a board that is obtained by exchanging any pair of tiles
    public Board twin() {
        if (twinBoard != null)
            return twinBoard;
        int i, j, x, y;
        while (true) {
            i = StdRandom.uniformInt(n);
            j = StdRandom.uniformInt(n);
            if (tiles[i][j] != 0)
                break;
        }

        while (true) {
            x = StdRandom.uniformInt(n);
            y = StdRandom.uniformInt(n);
            if (tiles[x][y] != 0 && (x != i || y != j))
                break;
        }

        int[][] tilesClone = new int[n][n];
        for (int k = 0; k < n; k++) {
            System.arraycopy(tiles[k], 0, tilesClone[k], 0, n);
        }
        exch(tilesClone, i, j, x, y);
        twinBoard = new Board(tilesClone);
        return twinBoard;
    }

    private int goalX(int tile) {
        if (tile == 0)
            throw new NumberFormatException();
        return (tile - 1) / n;
    }

    private int goalY(int tile) {
        if (tile == 0)
            throw new NumberFormatException();
        return (tile - 1) % n;
    }

    private int distanceToGoal(int tile, int x, int y) {
        return Math.abs(x - goalX(tile)) + Math.abs(y - goalY(tile));
    }

    private int isTileGoal(int tile, int x, int y) {
        if (x == goalX(tile) && y == goalY(tile))
            return 1;
        return 0;
    }

    private void exch(int[][] a, int ai, int aj, int bi, int bj) {
        int swap = a[ai][aj];
        a[ai][aj] = a[bi][bj];
        a[bi][bj] = swap;
    }

    // unit testing (not graded)
    public static void main(String[] args) {

    }
}